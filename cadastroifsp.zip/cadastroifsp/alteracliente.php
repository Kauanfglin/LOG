<?php
include('includes/conexao.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "SELECT * FROM cliente WHERE id = $id";
    $result = mysqli_query($con, $sql);

    if ($result) {
        
        if (mysqli_num_rows($result) == 1) {
            
            $row = mysqli_fetch_assoc($result);
        } else {
            echo "Cliente não encontrado.";
            exit; 
        }
    } else {
        echo "Erro ao consultar cliente: " . mysqli_error($con);
        exit; 
    }
} else {
    echo "ID do cliente não especificado.";
    exit; 
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alteração de Cliente</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f0f0f0;
        }
        form {
            max-width: 400px;
            margin: auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        fieldset {
            border: 1px solid #ccc;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        legend {
            font-size: 1.2em;
            margin-bottom: 10px;
        }
        label {
            display: block;
            margin-bottom: 8px;
        }
        input[type="text"], input[type="email"], input[type="password"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 3px;
            box-sizing: border-box;
            font-size: 1em;
        }
        button[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            font-size: 1em;
        }
        button[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <form action="alteraclienteExe.php" method="post">
        <fieldset>
            <legend>Alteração de Cliente</legend>
            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
            <div>
                <label for="nome">Nome:</label>
                <input type="text" name="nome" id="nome" value="<?php echo $row['nome']; ?>" required>
            </div>
            <div>
                <label for="email">E-mail:</label>
                <input type="email" name="email" id="email" value="<?php echo $row['email']; ?>" required>
            </div>
            <div>
                <label for="senha">Senha:</label>
                <input type="password" name="senha" id="senha" value="<?php echo $row['senha']; ?>" required>
            </div>
            <div style="text-align: center;">
                <button type="submit">Salvar Alterações</button>
            </div>
        </fieldset>    
    </form>
</body>
</html>
