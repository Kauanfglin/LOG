<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Clientes</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f0f0f0;
        }
        form {
            max-width: 400px;
            margin: auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        fieldset {
            border: 1px solid #ccc;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        legend {
            font-size: 1.2em;
            margin-bottom: 10px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        input[type="text"], input[type="email"], input[type="password"], select {
            width: calc(100% - 18px); 
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            box-sizing: border-box;
            font-size: 1em;
            margin-bottom: 10px;
        }
        button[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            font-size: 1em;
            transition: background-color 0.3s;
        }
        button[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <fieldset>
            <legend>Cadastro de Cliente</legend>
            <div>
                <label for="nome">Nome:</label>
                <input type="text" name="nome" id="nome" required>
            </div>
            <div>
                <label for="email">E-mail:</label>
                <input type="email" name="email" id="email" required>
            </div>
            <div>
                <label for="senha">Senha:</label>
                <input type="password" name="senha" id="senha" required>
            </div>
            <div>
                <label for="cidade">Cidade:</label>
                <select name="cidade" id="cidade" required>
                    <?php
                    include('includes/conexao.php');

                    $sql = "SELECT * FROM cidade";
                    $result = mysqli_query($con, $sql);

                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<option value='" . $row['id'] . "'>" . $row['nome'] . " - " . $row['estado'] . "</option>";
                        }
                    } else {
                        echo "<option value=''>Nenhuma cidade encontrada</option>";
                    }

                    mysqli_close($con);
                    ?>
                </select>
            </div>
            <div>
                <label for="ativo">Status:</label>
                <select name="ativo" id="ativo" required>
                    <option value="1">Ativo</option>
                    <option value="0">Não Ativo</option>
                </select>
            </div>
            <div style="text-align: center;">
                <button type="submit">Cadastrar</button>
            </div>
        </fieldset>    
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        include('includes/conexao.php');

        $nome = mysqli_real_escape_string($con, $_POST['nome']);
        $email = mysqli_real_escape_string($con, $_POST['email']);
        $senha = mysqli_real_escape_string($con, $_POST['senha']);
        $id_cidade = intval($_POST['cidade']); 
        $ativo = intval($_POST['ativo']);

        $sql_cidade = "SELECT nome, estado FROM cidade WHERE id = $id_cidade";
        $result_cidade = mysqli_query($con, $sql_cidade);

        if (mysqli_num_rows($result_cidade) > 0) {
            $row_cidade = mysqli_fetch_assoc($result_cidade);
            $nome_cidade = $row_cidade['nome'];
            $estado_cidade = $row_cidade['estado'];

            $sql = "INSERT INTO cliente (nome, email, senha, id_cidade, ativo) ";
            $sql .= "VALUES ('$nome', '$email', '$senha', $id_cidade, $ativo)";

            if (mysqli_query($con, $sql)) {
                echo "<h2>Dados cadastrados com sucesso!</h2>";
                echo "<p>Nome: $nome</p>";
                echo "<p>E-mail: $email</p>";
                echo "<p>Cidade: $nome_cidade - $estado_cidade</p>";
                echo "<p>Status: " . ($ativo == 1 ? 'Ativo' : 'Não Ativo') . "</p>";
            } else {
                echo "<h2>Erro ao cadastrar cliente:</h2>";
                echo "<p>" . mysqli_error($con) . "</p>";
            }
        } else {
            echo "<h2>Erro ao encontrar a cidade selecionada.</h2>";
        }

        mysqli_close($con);
    }
    ?>
</body>
</html>
