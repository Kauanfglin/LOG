<?php
include('includes/conexao.php');

$id = $_POST['id'];
$nome = $_POST['nome'];
$estado = $_POST['estado'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alteração de cidade</title>
</head>
<body>
    <h1>Alteração de cidade</h1>
    <?php 
    echo "<p>id: $id</p>";
    echo "<p>nome: $nome</p>";
    echo "<p>estado: $estado</p>";

    if (isset($con)) {
        $sql = "UPDATE cidade SET 
                nome = ?,
                estado = ?
                WHERE id = ?";
        
        $stmt = mysqli_prepare($con, $sql);

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "ssi", $nome, $estado, $id);

            $result = mysqli_stmt_execute($stmt);

            if ($result) {
                echo "Dados atualizados com sucesso";
            } else {
                echo "Erro ao atualizar dados: " . mysqli_error($con);
            }

            mysqli_stmt_close($stmt);
        } else {
            echo "Erro ao preparar a consulta: " . mysqli_error($con);
        }
    } else {
        echo "Erro: Conexão não inicializada.";
    }
    ?>
</body>
</html>
