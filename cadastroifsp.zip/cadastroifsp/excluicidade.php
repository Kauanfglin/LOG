<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deletar Cidade</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 20px;
            background-color: #f0f0f0;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background-color: #fff;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        h2 {
            text-align: center;
            margin-bottom: 10px;
        }
        p {
            text-align: center;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #dc3545;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .btn:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Deletar Cidade</h1>
        <?php
        include('includes/conexao.php');

        if (isset($_GET['id'])) {
            $id = $_GET['id'];

            $sql = "DELETE FROM cidade WHERE id = ?";
            
            $stmt = mysqli_prepare($con, $sql);

            if ($stmt) {
                mysqli_stmt_bind_param($stmt, "i", $id);

                $result = mysqli_stmt_execute($stmt);

                if ($result) {
                    echo "<h2>Dados deletados com sucesso</h2>";
                    echo "<p><a class='btn' href='ListaCidade.php'>Voltar para Lista de Cidades</a></p>";
                } else {
                    echo "<h2>Erro ao deletar dados</h2>";
                    echo "<p>" . mysqli_error($con) . "</p>";
                }

                mysqli_stmt_close($stmt);
            } else {
                echo "<h2>Erro ao preparar a consulta</h2>";
                echo "<p>" . mysqli_error($con) . "</p>";
            }
        } else {
            echo "<h2>Parâmetro 'id' não foi fornecido</h2>";
        }

        mysqli_close($con);
        ?>
    </div>
</body>
</html>
