<?php
    include('includes/conexao.php');
    $id = $_GET['id'];
    $sql = "SELECT * FROM cidade WHERE id = $id";
    $result = mysqli_query($con, $sql);
    $row = mysqli_fetch_array($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alteração de Cidades</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f0f0f0;
        }
        form {
            max-width: 400px;
            margin: auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        fieldset {
            border: 1px solid #ccc;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        legend {
            font-size: 1.2em;
            margin-bottom: 10px;
        }
        label {
            display: block;
            margin-bottom: 8px;
        }
        input[type="text"], select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 3px;
            box-sizing: border-box;
            font-size: 1em;
        }
        button[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            font-size: 1em;
        }
        button[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <form action="AlteraCidadeExe.php" method="post">
        <fieldset>
            <legend>Alteração de Cidades</legend>
            <div>
                <label for="nome">Nome:</label>
                <input type="text" name="nome" id="nome" required value="<?php echo htmlspecialchars($row['nome']); ?>">
            </div>
            <div>
                <label for="estado">Estado:</label>
                <select name="estado" id="estado" required>
                    <option value="SP" <?php echo ($row['estado'] == "SP") ? "selected" : ""; ?>>SP</option>
                    <option value="RJ" <?php echo ($row['estado'] == "RJ") ? "selected" : ""; ?>>RJ</option>
                    <option value="MG" <?php echo ($row['estado'] == "MG") ? "selected" : ""; ?>>MG</option>
                </select>
            </div>
            <div>
                <button type="submit">Atualizar</button>
            </div>
            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
        </fieldset>    
    </form>
</body>
</html>
