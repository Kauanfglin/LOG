<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Cliente</title>
</head>
<body>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        include('includes/conexao.php');

        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $senha = $_POST['senha'];
        $cidade_id = $_POST['cidade']; 

        echo "<h1>Dados do cliente</h1>";
        echo "Nome: $nome <br>";
        echo "Email: $email <br>";

        $sql_cidade = "SELECT nome FROM cidade WHERE id = $cidade_id";
        $result_cidade = mysqli_query($con, $sql_cidade);

        if (mysqli_num_rows($result_cidade) > 0) {
            $row_cidade = mysqli_fetch_assoc($result_cidade);
            $nome_cidade = $row_cidade['nome'];
            echo "Cidade: $nome_cidade <br>";
        } else {
            echo "Cidade não encontrada <br>";
        }

        $sql_cliente = "INSERT INTO cliente (nome, email, senha, cidade_id) ";
        $sql_cliente .= "VALUES ('$nome', '$email', '$senha', $cidade_id)";

        $result_cliente = mysqli_query($con, $sql_cliente);

        if ($result_cliente) {
            echo "<h2>Dados cadastrados com sucesso</h2>";
        } else {
            echo "<h2>Erro ao cadastrar cliente</h2>";
            echo mysqli_error($con);
        }
    } else {
        echo "<h2>Não foi possível processar o formulário.</h2>";
    }
    ?>

    <h3>Formulário de Cadastro de Cliente</h3>
    <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome" required><br><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br><br>

        <label for="senha">Senha:</label>
        <input type="password" id="senha" name="senha" required><br><br>

        <label for="cidade">Cidade:</label>
        <select id="cidade" name="cidade" required>
            <?php
            $sql_cidades = "SELECT * FROM cidade";
            $result_cidades = mysqli_query($con, $sql_cidades);

            if (mysqli_num_rows($result_cidades) > 0) {
                while ($row_cidades = mysqli_fetch_assoc($result_cidades)) {
                    echo "<option value='" . $row_cidades['id'] . "'>" . $row_cidades['nome'] . "</option>";
                }
            } else {
                echo "<option value=''>Nenhuma cidade encontrada</option>";
            }
            ?>
        </select><br><br>

        <input type="submit" value="Cadastrar">
    </form>
</body>
</html>
