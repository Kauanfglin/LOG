CREATE DATABASE IF NOT EXISTS IFSP;
USE IFSP;

CREATE TABLE cidade (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50),
    estado VARCHAR(2)
);

CREATE TABLE cliente (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50),
    email VARCHAR(50),
    senha VARCHAR(255), 
    ativo BOOLEAN DEFAULT true, 
    id_cidade INT,
    CONSTRAINT fk_ClienteCidade FOREIGN KEY (id_cidade) REFERENCES cidade(id),
    INDEX idx_id_cidade (id_cidade) 
);
